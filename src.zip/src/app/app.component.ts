import { Component } from '@angular/core';
import { MealServicesService } from './shared/services/meal-services.service';
import {
  getRecipieType,
  modifiedRecipieType,
} from './shared/Models/RecipieModels/RecipieType.interface';
import { Subject } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'RecipieApp';

 
  constructor(private mealService: MealServicesService) {}

  mealsArray:modifiedRecipieType={}as modifiedRecipieType;

  getRecipieData() {
    this.mealService.getData().subscribe((data) => {
     
      this.mealService.mealsArray$.next(data)

    });
  }
}


